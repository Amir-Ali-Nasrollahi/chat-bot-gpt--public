<?php

define("TOKEN", "bot7756905777:AAFMo-Mk1vvoZh1ehQgucosgwMNUQhiFvYY");
$url = "https://api.telegram.org/" . TOKEN ."/sendMessage";
define("TELEGRAM_URL", $url);

