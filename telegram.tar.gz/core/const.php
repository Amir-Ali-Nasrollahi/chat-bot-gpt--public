<?php

define("TOKEN", "bot6197638290:AAEnHr_MsRlQbDD7lq0KanSqyzQ5sBEhGi4");
$url = "https://api.telegram.org/" . TOKEN ."/sendMessage";
define("TELEGRAM_URL", $url);
