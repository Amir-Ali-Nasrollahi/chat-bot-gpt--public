<?php
// if(file_exists("./composer.json"))
    // include_once "./vendor/autoload.php";

include_once "./core/controller.php";
include_once "./core/const.php";
include_once "./core/app.php";

new Core\App();
