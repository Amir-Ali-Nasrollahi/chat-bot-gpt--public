<?php

include_once "./core/controller.php";
include_once "./core/const.php";
include_once "./core/app.php";

new Core\App();
